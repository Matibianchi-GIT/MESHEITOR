// Arena 3D FFGL Source v2.0 - fixed 20-parameter interface
// Requires official Resolume FFGL SDK and Assimp. No Blender dependency.
// Include Win32 user/COM types before the FFGL SDK and WIC headers.
// This avoids missing MSG/LPMSG in oleidl.h/ole2.h on Windows SDK 26100.
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <Windows.h>
#include <winuser.h>
#include "FFGLGradients.h"
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include <algorithm>
#include <cctype>
#include <map>
#include <unordered_map>
#include <functional>
#include <limits>
#include <cmath>
#include <fstream>
#include <random>
#include <wincodec.h>
#include <wrl/client.h>
#pragma comment(lib,"windowscodecs.lib")
using namespace ffglex;
using Microsoft::WRL::ComPtr;
namespace fs=std::filesystem;

// Changed parameter indices: new FFGL unique ID to avoid restoring obsolete presets.
static CFFGLPluginInfo PluginInfo(PluginFactory<FFGLGradients>,"MSH1","MESHEITOR",2,1,1,0,FF_SOURCE,"3D mesh source for Resolume Arena 7","MESHEITOR native FFGL source");
// Public FFGL parameters: order is explicit, stable and contiguous (0..19).
// Model Folder is the first control (text); 50 model slots are numeric, 1..50.
enum Param : unsigned {
 FOLDER=0, MODEL, MODEL_SCALE, CAMERA, AMBIENT,
 LIGHT, INTENSITY, LIGHT_HUE, LIGHT_SAT, SECONDARY_ON,
 SECONDARY_HUE, SECONDARY_SAT, ROT_X, ROT_Y, ROT_Z,
 RENDER_MODE, POINT_SIZE, EXPLODE, EXPLODE_NOISE, AUTOPLAY,
 COUNT
};
static_assert(COUNT == 20, "Arena3D must publish exactly 20 FFGL parameters");
static const char* names[COUNT]={
 "Model Folder", "Model", "Model Scale", "Camera", "Ambient",
 "Point Light Selector", "Light Power", "Light 1 Hue", "Light 1 Saturation", "Opposite Light",
 "Light 2 Hue", "Light 2 Saturation", "Rotate X", "Rotate Y", "Rotate Z",
 "Render Mode", "Point Size", "Explode", "Explode Noise", "Animation Autoplay"
};
static constexpr float kCubeSpread = 0.55f; // prior v1.9 default; no separate slider
static constexpr bool kHideBackgroundMeshes = true; // built-in, no separate slider
static const char* vs=R"GLSL(#version 410 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in float aSeed;
layout(location=4) in vec3 aFaceDirection;
layout(location=5) in vec2 aFaceMeta; // x: triangle seed, y: local corner index
uniform mat4 uMVP;
uniform mat4 uModel;
uniform float uExplode,uExplodeNoise,uDisplace,uTime;
uniform float uGlitchStretchAngle,uGlitchAxisAngle;
out vec3 vNormal,vPosition;
out vec2 vUV;
void main(){
 vec3 p=aPos;float t=uTime;
 // Rigid triangle shards: the same velocity/noise vector is used by all 3 corners.
 // Radial launch plus differing acceleration creates believable separation.
 float face=aFaceMeta.x;
 float rnd1=fract(sin(face*13.879+3.7)*43758.5453);
 float rnd2=fract(sin(face*51.119+1.2)*12741.2849);
 float rnd3=fract(sin(face*87.411+9.3)*31415.9265);
 vec3 radial=normalize(aFaceDirection+vec3(0.00001));
 vec3 tangent=normalize(cross(radial,abs(radial.y)<0.9?vec3(0,1,0):vec3(1,0,0)));
 vec3 binormal=normalize(cross(radial,tangent));
 float speedMix=0.55+1.5*rnd1;
 // Smooth, deterministic 3D noise in time, varying per face rather than per vertex.
 vec3 noiseVec=vec3(sin(t*(0.62+rnd1*0.4)+rnd2*6.28318),
                    sin(t*(0.83+rnd2*0.3)+rnd3*6.28318),
                    cos(t*(0.71+rnd3*0.5)+rnd1*6.28318));
 vec3 trajectory=radial*(1.9*speedMix)
               +tangent*(rnd2-0.5)*1.7
               +binormal*(rnd3-0.5)*1.7;
 // Velocity drift and turbulence remain active while Explode > 0.
 // No distortion of corners inside a triangle.
 vec3 explosion=trajectory+uExplodeNoise*(noiseVec*0.82+radial*0.26*sin(t*1.1+rnd3*6.28318));
 p+=uExplode*explosion;
 // Directional broken-geometry displacement based on the supplied references.
 // Face hash is shared by all three vertices; aFaceMeta.y singles out a
 // corner, creating long thin triangular blades rather than uniform inflation.
 float h=fract(sin(aFaceMeta.x*91.17+3.12)*43758.5453);
 float h2=fract(sin(aFaceMeta.x*37.91+1.71)*21453.234);
 float band=step(0.42,h);
 float spike=step(0.66,h2);
 float corner=step(1.5,aFaceMeta.y); // only local vertex 2
 // Both angles cover a full circle in the local XY plane, independently.
 // 0 degrees = +X, 90 = +Y, 180 = -X, 270 = -Y.
 const float TAU=6.28318530718;
 float axisAngle=uGlitchAxisAngle*TAU;
 float stretchAngle=uGlitchStretchAngle*TAU;
 vec3 displacementAxis=vec3(cos(axisAngle),sin(axisAngle),0.0);
 vec3 stretchAxis=vec3(cos(stretchAngle),sin(stretchAngle),0.0);
 // Move selected faces along Glitch Axis; pull only one vertex along
 // Glitch Stretch direction to form long fragmented geometry.
 vec3 rigid=displacementAxis*(h2-0.5)*uDisplace*1.45*band;
 vec3 blade=stretchAxis*2.30*uDisplace*spike*corner;
 float micro=sin(p.y*30.0+h*TAU+t*.23)*0.12*uDisplace;
 p+=rigid+blade+aFaceDirection*micro*band;
 vec4 wp=uModel*vec4(p,1.0);
 vPosition=wp.xyz;vNormal=mat3(uModel)*aNormal;vUV=aUV;
 gl_Position=uMVP*vec4(p,1.0);
}
)GLSL";
static const char* fsCode=R"GLSL(#version 410 core
in vec3 vNormal,vPosition;in vec2 vUV;
out vec4 fragColor;
uniform vec3 uLight;
uniform vec3 uLightSecondary;
uniform vec3 uCamera;
uniform float uPower,uAmbient,uSecondaryEnabled;
uniform vec3 uLightColor,uSecondaryColor;
uniform sampler2D uTexture;
uniform int uHasTexture;
vec3 contribution(vec3 pos,vec3 color,vec3 n,float strength){
 vec3 delta=pos-vPosition;
 float d=max(length(delta),0.0001);
 vec3 direction=delta/d;
 float diffuse=max(dot(n,direction),0.0);
 float attenuation=1.0/(1.0+0.24*d*d);
 vec3 halfDir=normalize(direction+normalize(uCamera-vPosition));
 float spec=pow(max(dot(n,halfDir),0.0),40.0)*0.22;
 return color*strength*attenuation*(diffuse*2.4+spec);
}
void main(){
 vec4 textureColor=(uHasTexture==1)?texture(uTexture,vUV):vec4(0.67,0.77,0.93,1.0);
 vec3 n=normalize(vNormal);
 vec3 lit=vec3(uAmbient)+contribution(uLight,uLightColor,n,uPower);
 lit+=contribution(uLightSecondary,uSecondaryColor,n,uPower*uSecondaryEnabled);
 fragColor=vec4(textureColor.rgb*lit,textureColor.a);
}
)GLSL";

namespace {
struct V3{float x,y,z;};
// Hue 0..1 wraps 0..360 degrees; saturation 0 = white, 1 = full hue.
V3 hueSaturation(float hue,float sat){
 float h=std::fmod(std::max(0.f,hue)*6.f,6.f);
 float s=std::clamp(sat,0.f,1.f);
 float x=1.f-std::abs(std::fmod(h,2.f)-1.f);
 V3 raw=(h<1.f)?V3{1.f,x,0.f}:(h<2.f)?V3{x,1.f,0.f}:
        (h<3.f)?V3{0.f,1.f,x}:(h<4.f)?V3{0.f,x,1.f}:
        (h<5.f)?V3{x,0.f,1.f}:V3{1.f,0.f,x};
 return {1.f-s+s*raw.x,1.f-s+s*raw.y,1.f-s+s*raw.z};
}

V3 operator-(V3 a,V3 b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
V3 cross(V3 a,V3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
V3 norm(V3 a){float d=std::sqrt(a.x*a.x+a.y*a.y+a.z*a.z);return d>0.00001f?V3{a.x/d,a.y/d,a.z/d}:V3{0,0,1};}
struct M4{float m[16]{};};
M4 identity(){M4 m;for(int i=0;i<4;i++)m.m[i*5]=1;return m;}
M4 multiply(M4 a,M4 b){M4 c;for(int col=0;col<4;col++)for(int row=0;row<4;row++)for(int k=0;k<4;k++)c.m[col*4+row]+=a.m[k*4+row]*b.m[col*4+k];return c;}
M4 perspective(float fov,float aspect){M4 p;float f=1/std::tan(fov*0.5f);p.m[0]=f/aspect;p.m[5]=f;p.m[10]=-1.002002f;p.m[11]=-1;p.m[14]=-0.2002002f;return p;}
M4 lookat(V3 eye,V3 target){V3 f=norm(target-eye),up={0,1,0};if(std::abs(f.y)>.995f)up={0,0,1};V3 s=norm(cross(f,up)),u=cross(s,f);M4 m=identity();m.m[0]=s.x;m.m[4]=s.y;m.m[8]=s.z;m.m[1]=u.x;m.m[5]=u.y;m.m[9]=u.z;m.m[2]=-f.x;m.m[6]=-f.y;m.m[10]=-f.z;m.m[12]=-(s.x*eye.x+s.y*eye.y+s.z*eye.z);m.m[13]=-(u.x*eye.x+u.y*eye.y+u.z*eye.z);m.m[14]=f.x*eye.x+f.y*eye.y+f.z*eye.z;return m;}
V3 grid(int n,float spread){n=std::clamp(n,1,27)-1;return {(float(n%3)-1)*spread,(float((n/3)%3)-1)*spread,(float(n/9)-1)*spread};}
int discretize(float v,int max){return std::clamp(int(std::lround(v*max)),0,max);}
// Animated Assimp nodes are evaluated every frame, including bone channels.
static aiMatrix4x4 weightedMatrix(const aiMatrix4x4& a,float w){
 aiMatrix4x4 r=a;float* p=&r.a1;for(int i=0;i<16;i++)p[i]*=w;return r;
}
static void addMatrix(aiMatrix4x4& a,const aiMatrix4x4& b){float* x=&a.a1;const float* y=&b.a1;for(int i=0;i<16;i++)x[i]+=y[i];}
static aiVector3D transformPoint(const aiMatrix4x4& m,const aiVector3D& v){return m*v;}
static aiVector3D transformDirection(const aiMatrix4x4& m,const aiVector3D& v){
 aiMatrix3x3 n(m); n.Inverse().Transpose(); aiVector3D r=n*v; r.Normalize();return r;
}
static aiVector3D interpolatePosition(const aiVectorKey* keys,unsigned count,double t){
 if(!count)return aiVector3D();if(count==1||t<=keys[0].mTime)return keys[0].mValue;
 for(unsigned i=0;i+1<count;i++)if(t<keys[i+1].mTime){double dt=keys[i+1].mTime-keys[i].mTime;float a=dt>0?float((t-keys[i].mTime)/dt):0.f;return keys[i].mValue*(1-a)+keys[i+1].mValue*a;}
 return keys[count-1].mValue;
}
static aiQuaternion interpolateRotation(const aiQuatKey* keys,unsigned count,double t){
 if(!count)return aiQuaternion();if(count==1||t<=keys[0].mTime)return keys[0].mValue;
 for(unsigned i=0;i+1<count;i++)if(t<keys[i+1].mTime){double dt=keys[i+1].mTime-keys[i].mTime;float a=dt>0?float((t-keys[i].mTime)/dt):0.f;aiQuaternion result;aiQuaternion::Interpolate(result,keys[i].mValue,keys[i+1].mValue,a);result.Normalize();return result;}
 return keys[count-1].mValue;
}
static aiMatrix4x4 animatedLocal(const aiNode* node,const std::unordered_map<std::string,const aiNodeAnim*>& channels,double ticks){
 auto it=channels.find(node->mName.C_Str());if(it==channels.end())return node->mTransformation;
 auto* ch=it->second;
 aiVector3D pos,sca;aiQuaternion rot;node->mTransformation.Decompose(sca,rot,pos);
 if(ch->mNumPositionKeys)pos=interpolatePosition(ch->mPositionKeys,ch->mNumPositionKeys,ticks);
 if(ch->mNumRotationKeys)rot=interpolateRotation(ch->mRotationKeys,ch->mNumRotationKeys,ticks);
 if(ch->mNumScalingKeys)sca=interpolatePosition(ch->mScalingKeys,ch->mNumScalingKeys,ticks);
 aiMatrix4x4 translate,rotation(rot.GetMatrix()),scale;
 aiMatrix4x4::Translation(pos,translate);aiMatrix4x4::Scaling(sca,scale);
 return translate*rotation*scale;
}
}
FFGLGradients::FFGLGradients(){
 SetMinInputs(0);SetMaxInputs(0);
 // Values follow the exact public parameter order. Text folder is stored separately.
 values_={
  0.f,      // Model Folder (unused float; text lives in folder_)
  0.f,      // Model 01 / 50
  0.f,      // Model Scale 1x (max 10x)
  14.f/27.f,// Camera center
  0.18f,    // Ambient
  14.f/27.f,// Point Light Selector
  0.75f,    // Light Power
  0.f,      // Light 1 Hue
  0.f,      // Light 1 Saturation (white)
  0.f,      // Opposite Light off
  0.58f,    // Light 2 Hue
  0.85f,    // Light 2 Saturation
  0.f,0.f,0.f, // Rotate X / Y / Z
  0.f,      // Render Mode: textured
  0.3f,    // Point Size
  0.f,      // Explode
  0.35f,    // Explode Noise
  1.f       // Animation Autoplay
 };
 folder_=(fs::path(getenv("USERPROFILE")?getenv("USERPROFILE"):".")/"Documents"/"Resolume"/"Arena3D"/"Models").string();
 for(unsigned i=0;i<COUNT;i++){
  if(i==FOLDER) SetParamInfo(i,names[i],FF_TYPE_TEXT,folder_.c_str());
  else SetParamInfof(i,names[i],(i==SECONDARY_ON||i==AUTOPLAY)?FF_TYPE_BOOLEAN:FF_TYPE_STANDARD);
 }
 status_="Not loaded";started_=std::chrono::steady_clock::now();
}
FFResult FFGLGradients::SetFloatParameter(unsigned i,float v){if(i==FOLDER||i>=COUNT)return FF_FAIL;values_[i]=std::clamp(v,0.f,1.f);if(i==MODEL)reload_=true;return FF_SUCCESS;}
float FFGLGradients::GetFloatParameter(unsigned i){return (i<COUNT && i!=FOLDER)?values_[i]:0.f;}
FFResult FFGLGradients::SetTextParameter(unsigned i,const char* v){if(i!=FOLDER||!v)return FF_FAIL;folder_=v;selected_=-1;loaded_.clear();reload_=true;return FF_SUCCESS;}
char* FFGLGradients::GetTextParameter(unsigned i){return i==FOLDER?const_cast<char*>(folder_.c_str()):nullptr;}
FFResult FFGLGradients::InitGL(const FFGLViewportStruct* vp){
 if(!shader_.Compile(vs,fsCode))return FF_FAIL;
 width_=vp ? vp->width : 1920; height_=vp ? vp->height : 1080;
 started_=std::chrono::steady_clock::now();lastFrame_=started_;animationSeconds_=0;reload_=true;
 return CFFGLPlugin::InitGL(vp);
}
void FFGLGradients::releaseModel(){for(auto& p:parts_){if(p.vao)glDeleteVertexArrays(1,&p.vao);if(p.vbo)glDeleteBuffers(1,&p.vbo);if(p.ebo)glDeleteBuffers(1,&p.ebo);if(p.texture)glDeleteTextures(1,&p.texture);}parts_.clear();scene_=nullptr;importer_.reset();}
GLuint FFGLGradients::loadTexture(const fs::path& file){
 // WIC supports PNG/JPEG/TIFF/BMP. Textures are kept local to model folder.
 HRESULT hr=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
 bool uninit=SUCCEEDED(hr);
 ComPtr<IWICImagingFactory> factory;ComPtr<IWICBitmapDecoder> decoder;ComPtr<IWICBitmapFrameDecode> frame;ComPtr<IWICFormatConverter> conv;
 GLuint tex=0;
 do{
  if(FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory))))break;
  if(FAILED(factory->CreateDecoderFromFilename(file.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&decoder)))break;
  if(FAILED(decoder->GetFrame(0,&frame)))break;
  if(FAILED(factory->CreateFormatConverter(&conv)))break;
  if(FAILED(conv->Initialize(frame.Get(),GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom)))break;
  UINT w=0,h=0;if(FAILED(conv->GetSize(&w,&h))||!w||!h||w>8192||h>8192)break;
  std::vector<unsigned char> pixels(size_t(w)*h*4);
  if(FAILED(conv->CopyPixels(nullptr,w*4,UINT(pixels.size()),pixels.data())))break;
  glGenTextures(1,&tex);glBindTexture(GL_TEXTURE_2D,tex);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glGenerateMipmap(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,0);
 }while(false);
 // Release COM objects before uninitializing apartment.
 conv.Reset();frame.Reset();decoder.Reset();factory.Reset();if(uninit)CoUninitialize();return tex;
}
bool FFGLGradients::loadModel(const fs::path& file){
 auto newImporter=std::make_unique<Assimp::Importer>();
 // IMPORTANT: PreTransformVertices destroys animation and is deliberately omitted.
 const aiScene* newScene=newImporter->ReadFile(file.string(),aiProcess_Triangulate|aiProcess_GenSmoothNormals|aiProcess_FlipUVs|aiProcess_LimitBoneWeights);
 if(!newScene||!newScene->HasMeshes()||!newScene->mRootNode){status_="Import failed: "+std::string(newImporter->GetErrorString());return false;}
 std::vector<Part> incoming;
 // Create a separate drawable instance per node/mesh so node animation works.
 std::function<void(const aiNode*)> create=[&](const aiNode* node){
  for(unsigned j=0;j<node->mNumMeshes;j++){
   unsigned mi=node->mMeshes[j];if(mi>=newScene->mNumMeshes)continue;
   const aiMesh* mesh=newScene->mMeshes[mi];std::vector<unsigned> indices;
   for(unsigned k=0;k<mesh->mNumFaces;k++){const aiFace& face=mesh->mFaces[k];for(unsigned t=0;t<face.mNumIndices;t++)indices.push_back(face.mIndices[t]);}
   if(indices.empty()||!mesh->mNumVertices)continue;
   Part part;part.meshIndex=mi;part.node=node;part.count=(GLsizei)indices.size();part.vertices.resize(mesh->mNumVertices);part.triangles=indices;
   // Only names explicitly designating a ground/background object are filtered.
   auto isBackgroundName=[](const std::string& name) {
    std::string lower=name;
    std::transform(lower.begin(),lower.end(),lower.begin(),[](unsigned char ch){return char(std::tolower(ch));});
    // Match common dedicated scene surfaces, not arbitrary words like "grounded".
    // 01.fbx supplied by the user contains a mesh node named "bg_plane"
    // and material "bg_mat". Earlier prefix-only matching missed both.
    static const char* exact[] = {"bg_plane","bg_mat","bg","background_plane","background_mesh"};
    for(const char* term:exact) if(lower==term) return true;
    static const char* terms[]={"plane","floor","ground","background","backdrop","piso","suelo"};
    for(const char* term:terms){const std::string key(term);
      if(lower==key || lower.rfind(key+".",0)==0 || lower.rfind(key+"_",0)==0 || lower.rfind(key+"-",0)==0) return true;
      // Also accept a scene prefix (e.g., "bg_plane"), but not "halo_bg".
      if(lower.size()>key.size()+1 && lower.compare(lower.size()-key.size(),key.size(),key)==0 &&
         (lower[lower.size()-key.size()-1]=='_' || lower[lower.size()-key.size()-1]=='-')) {
        if(key=="plane" || key=="background" || key=="backdrop") return true;
      }
    }
    return false;
   };
   part.backgroundMesh=isBackgroundName(mesh->mName.C_Str()) || isBackgroundName(node->mName.C_Str());
   if(newScene->HasMaterials() && mesh->mMaterialIndex<newScene->mNumMaterials){
      aiString materialName;
      if(newScene->mMaterials[mesh->mMaterialIndex]->Get(AI_MATKEY_NAME,materialName)==AI_SUCCESS)
       part.backgroundMesh=part.backgroundMesh || isBackgroundName(materialName.C_Str());
   }
   glGenVertexArrays(1,&part.vao);glBindVertexArray(part.vao);
   glGenBuffers(1,&part.vbo);glBindBuffer(GL_ARRAY_BUFFER,part.vbo);glBufferData(GL_ARRAY_BUFFER,part.triangles.size()*sizeof(Vertex),nullptr,GL_DYNAMIC_DRAW);
   glGenBuffers(1,&part.ebo);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,part.ebo);std::vector<unsigned> sequential(indices.size());for(size_t ix=0;ix<sequential.size();++ix)sequential[ix]=unsigned(ix);
   glBufferData(GL_ELEMENT_ARRAY_BUFFER,sequential.size()*sizeof(unsigned),sequential.data(),GL_STATIC_DRAW);
   glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,p));
   glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,n));
   glEnableVertexAttribArray(2);glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,uv));
   glEnableVertexAttribArray(3);glVertexAttribPointer(3,1,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,seed));
   glEnableVertexAttribArray(4);glVertexAttribPointer(4,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,faceDirection));
   glEnableVertexAttribArray(5);glVertexAttribPointer(5,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,faceSeed));
   glBindVertexArray(0);
   if(newScene->HasMaterials()&&mesh->mMaterialIndex<newScene->mNumMaterials){aiString name;
    auto* mat=newScene->mMaterials[mesh->mMaterialIndex];
    if(mat->GetTexture(aiTextureType_DIFFUSE,0,&name)==AI_SUCCESS){
     fs::path tex=fs::u8path(name.C_Str());if(!tex.is_absolute())tex=file.parent_path()/tex;
     if(fs::exists(tex))part.texture=loadTexture(tex);
    }
   }
   incoming.push_back(std::move(part));
  }
  for(unsigned j=0;j<node->mNumChildren;j++)create(node->mChildren[j]);
 };
 create(newScene->mRootNode);
 if(incoming.empty()){status_="No drawable meshes";return false;}
 releaseModel();importer_=std::move(newImporter);scene_=importer_->GetScene();parts_=std::move(incoming);
 normalizedScale_=0;updateAnimation(0.f); // Compute fixed fitting scale using bind/rest pose.
 loaded_=file;status_=std::string("Loaded ")+file.filename().string()+(scene_->HasAnimations()?" [loop animation]":" [static]");
 started_=std::chrono::steady_clock::now();lastFrame_=started_;animationSeconds_=0;return true;
}
void FFGLGradients::updateAnimation(float seconds){
 if(!scene_||parts_.empty())return;
 const aiAnimation* anim=(scene_->HasAnimations()&&scene_->mNumAnimations)?scene_->mAnimations[0]:nullptr;
 double ticks=0;
 if(anim&&anim->mDuration>0){double fps=anim->mTicksPerSecond>0?anim->mTicksPerSecond:25.0;
  double speed=1.0; // Fixed playback speed; no Speed slider.
  ticks=std::fmod(double(seconds)*fps*speed,anim->mDuration);
 }
 std::unordered_map<std::string,const aiNodeAnim*> channels;
 if(anim)for(unsigned i=0;i<anim->mNumChannels;i++)channels[anim->mChannels[i]->mNodeName.C_Str()]=anim->mChannels[i];
 std::unordered_map<const aiNode*,aiMatrix4x4> globals;
 std::unordered_map<std::string,aiMatrix4x4> named;
 std::function<void(const aiNode*,const aiMatrix4x4&)> visit=[&](const aiNode* n,const aiMatrix4x4& parent){
  aiMatrix4x4 m=parent*animatedLocal(n,channels,ticks);globals[n]=m;named[n->mName.C_Str()]=m;
  for(unsigned i=0;i<n->mNumChildren;i++)visit(n->mChildren[i],m);
 };
 visit(scene_->mRootNode,aiMatrix4x4());
 aiVector3D low(1e30f,1e30f,1e30f),high(-1e30f,-1e30f,-1e30f);
 for(auto& part:parts_){
  const aiMesh* mesh=scene_->mMeshes[part.meshIndex];
  std::vector<aiMatrix4x4> skin(mesh->mNumVertices,aiMatrix4x4());
  std::vector<float> weights(mesh->mNumVertices,0.f);
  if(mesh->HasBones()){
   for(unsigned b=0;b<mesh->mNumBones;b++){
    const aiBone* bone=mesh->mBones[b];auto it=named.find(bone->mName.C_Str());if(it==named.end())continue;
    aiMatrix4x4 boneTransform=it->second*bone->mOffsetMatrix;
    for(unsigned w=0;w<bone->mNumWeights;w++){auto vw=bone->mWeights[w];if(vw.mVertexId>=mesh->mNumVertices)continue;
     // aiMatrix4x4 default ctor is identity; accumulate weighted entries explicitly.
     aiMatrix4x4& out=skin[vw.mVertexId];float ww=vw.mWeight;
     if(weights[vw.mVertexId]==0)out=weightedMatrix(boneTransform,ww);
     else addMatrix(out,weightedMatrix(boneTransform,ww));
     weights[vw.mVertexId]+=ww;
    }
   }
  }
  const aiMatrix4x4 nodeTransform=globals[part.node];
  for(unsigned i=0;i<mesh->mNumVertices;i++){
   aiMatrix4x4 xf=nodeTransform;
   if(mesh->HasBones()&&weights[i]>1e-6f){xf=skin[i];if(weights[i]<0.999f)xf=weightedMatrix(xf,1.f/weights[i]);}
   aiVector3D pos=transformPoint(xf,mesh->mVertices[i]);
   aiVector3D n=mesh->HasNormals()?transformDirection(xf,mesh->mNormals[i]):aiVector3D(0,1,0);
   aiVector3D uv=mesh->HasTextureCoords(0)?mesh->mTextureCoords[0][i]:aiVector3D();
   float seed=std::sin(float(i)*12.9898f+float(part.meshIndex)*78.233f)*43758.5453f;seed-=std::floor(seed);
   part.vertices[i]={ {pos.x,pos.y,pos.z},{n.x,n.y,n.z},{uv.x,uv.y},seed };
    if(!(kHideBackgroundMeshes && part.backgroundMesh)){
      low.x=std::min(low.x,pos.x);low.y=std::min(low.y,pos.y);low.z=std::min(low.z,pos.z);
      high.x=std::max(high.x,pos.x);high.y=std::max(high.y,pos.y);high.z=std::max(high.z,pos.z);
    }
  }
 }
  if(low.x>high.x) { low=aiVector3D(-1.f,-1.f,-1.f);high=aiVector3D(1.f,1.f,1.f); }
 aiVector3D center=(low+high)*0.5f;
 float span=std::max({high.x-low.x,high.y-low.y,high.z-low.z,0.001f});
 if(normalizedScale_<=0.f)normalizedScale_=2.5f/span;
 // Recenter bounding box *per frame*. Animation translates/rotates around screen origin.
 for(auto& part:parts_){for(auto& v:part.vertices){v.p[0]=(v.p[0]-center.x)*normalizedScale_;v.p[1]=(v.p[1]-center.y)*normalizedScale_;v.p[2]=(v.p[2]-center.z)*normalizedScale_;}
  // Expand indexed mesh into independent triangle corners.  All three
  // corners share a direction computed from the animated face centroid.
  // This separates faces rather than pushing each shared vertex along its normal.
  part.drawVertices.clear();part.drawVertices.reserve(part.triangles.size());
  for(size_t tri=0;tri+2<part.triangles.size();tri+=3){
   unsigned i0=part.triangles[tri],i1=part.triangles[tri+1],i2=part.triangles[tri+2];
   if(i0>=part.vertices.size()||i1>=part.vertices.size()||i2>=part.vertices.size())continue;
   const auto& a=part.vertices[i0];const auto& b=part.vertices[i1];const auto& c=part.vertices[i2];
   V3 centroid{(a.p[0]+b.p[0]+c.p[0])/3.f,(a.p[1]+b.p[1]+c.p[1])/3.f,(a.p[2]+b.p[2]+c.p[2])/3.f};
   V3 direction=norm(centroid);
   // If a face is centered precisely at origin, use its geometric face normal.
   if(std::abs(centroid.x)+std::abs(centroid.y)+std::abs(centroid.z)<0.0001f){
    direction=norm(cross({b.p[0]-a.p[0],b.p[1]-a.p[1],b.p[2]-a.p[2]},
                         {c.p[0]-a.p[0],c.p[1]-a.p[1],c.p[2]-a.p[2]}));
   }
   const float faceSeed=float((tri/3) % 65521) * 0.6180339887f + float(part.meshIndex)*0.137f;
   const Vertex* corners[3]={&a,&b,&c};
   for(int corner=0;corner<3;corner++){
    Vertex v=*corners[corner];v.faceDirection[0]=direction.x;v.faceDirection[1]=direction.y;v.faceDirection[2]=direction.z;
    v.faceSeed=faceSeed;v.corner=float(corner);
    part.drawVertices.push_back(v);
   }
  }
  glBindBuffer(GL_ARRAY_BUFFER,part.vbo);
  if(!part.drawVertices.empty())glBufferSubData(GL_ARRAY_BUFFER,0,part.drawVertices.size()*sizeof(Vertex),part.drawVertices.data());
 }
 glBindBuffer(GL_ARRAY_BUFFER,0);
}
void FFGLGradients::createFallback(){
 // Source without imported model renders an explicit fallback 3D tetrahedron.
 // This is intentionally obvious so operators don't mistake fallback for a loaded FBX.
 static float positions[4][3]={{0,1,0},{-.9f,-.6f,.65f},{.9f,-.6f,.65f},{0,-.6f,-1}};
 static unsigned faces[12]={0,1,2,0,2,3,0,3,1,1,3,2};
 std::vector<Vertex> v;std::vector<unsigned> indices;
 for(unsigned k=0;k<12;k+=3){auto a=positions[faces[k]],b=positions[faces[k+1]],c=positions[faces[k+2]];V3 n=norm(cross({b[0]-a[0],b[1]-a[1],b[2]-a[2]},{c[0]-a[0],c[1]-a[1],c[2]-a[2]}));
  for(int j=0;j<3;j++){auto p=positions[faces[k+j]];v.push_back({{p[0],p[1],p[2]},{n.x,n.y,n.z},{j==0?0.f:1.f,j==2?1.f:0.f},float(k+j)/12.f});indices.push_back(unsigned(indices.size()));}}
 Part part;glGenVertexArrays(1,&part.vao);glBindVertexArray(part.vao);
 glGenBuffers(1,&part.vbo);glBindBuffer(GL_ARRAY_BUFFER,part.vbo);glBufferData(GL_ARRAY_BUFFER,v.size()*sizeof(Vertex),v.data(),GL_STATIC_DRAW);
 glGenBuffers(1,&part.ebo);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,part.ebo);std::vector<unsigned> sequential(indices.size());for(size_t ix=0;ix<sequential.size();++ix)sequential[ix]=unsigned(ix);
   glBufferData(GL_ELEMENT_ARRAY_BUFFER,sequential.size()*sizeof(unsigned),sequential.data(),GL_STATIC_DRAW);
 glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,p));
 glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,n));
 glEnableVertexAttribArray(2);glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,uv));
 glEnableVertexAttribArray(3);glVertexAttribPointer(3,1,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,seed));
   glEnableVertexAttribArray(4);glVertexAttribPointer(4,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,faceDirection));
   glEnableVertexAttribArray(5);glVertexAttribPointer(5,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,faceSeed));
 glBindVertexArray(0);part.count=(GLsizei)indices.size();parts_.push_back(part);
}
bool FFGLGradients::scanAndLoad(){
 // Fixed correspondence: model slot N loads file 01.fbx, 02.fbx, etc.
 // Fixed range 01..50, independent of actual file count.
 // Missing IDs never shift other selections.
 files_.clear();
 std::map<int, fs::path> byId;
 std::error_code ec;
 if(fs::is_directory(folder_,ec)) {
  for(const auto& entry : fs::directory_iterator(folder_,fs::directory_options::skip_permission_denied,ec)) {
   if(!entry.is_regular_file(ec)) continue;
   fs::path path=entry.path();
   std::string ext=path.extension().string();
   std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
   if(ext!=".fbx" && ext!=".obj" && ext!=".gltf" && ext!=".glb") continue;
   std::string stem=path.stem().string();
   if(stem.empty() || !std::all_of(stem.begin(),stem.end(),[](unsigned char c){return c>='0'&&c<='9';})) continue;
   int id=0;
   try { id=std::stoi(stem); } catch(...) { continue; }
   if(id<1 || id>50) continue;
   // If two formats share a number, prefer FBX, then GLB, GLTF, OBJ.
   auto rank=[](const fs::path& p){
    std::string e=p.extension().string();
    std::transform(e.begin(),e.end(),e.begin(),[](unsigned char c){return char(std::tolower(c));});
    return e==".fbx"?0:e==".glb"?1:e==".gltf"?2:3;
   };
   auto existing=byId.find(id);
   if(existing==byId.end() || rank(path)<rank(existing->second)) byId[id]=path;
  }
 }
 if(byId.empty()) {
  releaseModel();createFallback();selected_=-1;loaded_.clear();
  status_="No numbered models (01.fbx, 02.fbx...) in folder";
  return false;
 }
 // FFGL standard parameters are normalized [0, 1]. Exactly 50 slots.
 // 0.0 => 01, 1.0 => 50, with 49 equal intervals.
 int requested=std::clamp(1+int(std::lround(values_[MODEL]*49.0f)),1,50);
 auto chosen=byId.find(requested);
 if(chosen==byId.end()) {
  releaseModel();createFallback();selected_=requested;loaded_.clear();
  status_="Model number "+std::to_string(requested)+" missing (no renumbering)";
  return false;
 }
 if(selected_==requested && loaded_==chosen->second && !parts_.empty()) return true;
 selected_=requested;
 if(!loadModel(chosen->second)){releaseModel();createFallback();return false;}
 return true;
}
FFResult FFGLGradients::ProcessOpenGL(ProcessOpenGLStruct*){
 if(reload_){reload_=false;scanAndLoad();}
 if(parts_.empty())createFallback();
 auto now=std::chrono::steady_clock::now();float t=std::chrono::duration<float>(now-started_).count();
 // Accumulate playback time only when Autoplay is enabled.  STOP freezes pose;
 // PLAY resumes from exactly the same time, without jumping ahead.
 double frameDt=std::chrono::duration<double>(now-lastFrame_).count();lastFrame_=now;
 if(values_[AUTOPLAY]>=0.5f)animationSeconds_+=std::clamp(frameDt,0.0,0.25);
 if(scene_)updateAnimation(float(animationSeconds_));
 int l=discretize(values_[LIGHT],27),c=std::clamp(discretize(values_[CAMERA],27),1,27);
 float spread=2.0f+kCubeSpread*6.0f;
 V3 light=grid(std::max(1,l),spread),cam=grid(c,spread);
 // Opposite 3x3x3 cell maps 1<->27, 2<->26 and 14<->14.
 const int opposite=28-std::max(1,l);
 V3 secondaryLight=grid(opposite,spread);
 // Camera points to the model center; perspective FOV fixed (Zoom removed).
 if(c==14)cam={0.f,0.f,spread*2.5f};
 float camDistance=std::sqrt(cam.x*cam.x+cam.y*cam.y+cam.z*cam.z);
 if(camDistance<3.f){float k=3.f/std::max(camDistance,0.001f);cam={cam.x*k,cam.y*k,cam.z*k};}
 float fov=65.f*3.14159265f/180.f;
 // Standard perspective projection.
 float aspect=height_ ? float(width_)/float(height_) : 1.7777f;
 // Independent Euler sliders: 0..1 maps to 0..360 degrees, no automatic spin.
 float ax=values_[ROT_X]*6.283185307f,ay=values_[ROT_Y]*6.283185307f,az=values_[ROT_Z]*6.283185307f;
 M4 rx=identity(),ry=identity(),rz=identity();
 rx.m[5]=std::cos(ax);rx.m[6]=std::sin(ax);rx.m[9]=-std::sin(ax);rx.m[10]=std::cos(ax);
 ry.m[0]=std::cos(ay);ry.m[2]=-std::sin(ay);ry.m[8]=std::sin(ay);ry.m[10]=std::cos(ay);
 rz.m[0]=std::cos(az);rz.m[1]=std::sin(az);rz.m[4]=-std::sin(az);rz.m[5]=std::cos(az);
 // Uniform scale: 0.0 -> 1x, 1.0 -> 10x; model remains centered.
  float modelScale=1.0f+9.0f*values_[MODEL_SCALE];
  M4 scaleMatrix=identity();scaleMatrix.m[0]=modelScale;scaleMatrix.m[5]=modelScale;scaleMatrix.m[10]=modelScale;
  M4 model=multiply(multiply(multiply(rz,ry),rx),scaleMatrix);
 M4 mvp=multiply(multiply(perspective(fov,aspect),lookat(cam,{0,0,0})),model);

 GLint prevProgram=0,prevVAO=0,prevTex=0;GLboolean depth=glIsEnabled(GL_DEPTH_TEST),blend=glIsEnabled(GL_BLEND),scissor=glIsEnabled(GL_SCISSOR_TEST);
 glGetIntegerv(GL_CURRENT_PROGRAM,&prevProgram);glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&prevVAO);glGetIntegerv(GL_TEXTURE_BINDING_2D,&prevTex);
 GLfloat oldClear[4];glGetFloatv(GL_COLOR_CLEAR_VALUE,oldClear);
  GLboolean oldMask[4];glGetBooleanv(GL_COLOR_WRITEMASK,oldMask);
  glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
  glDisable(GL_SCISSOR_TEST);glEnable(GL_DEPTH_TEST);glDisable(GL_BLEND);
  // Source output clears to transparent RGBA; only triangles write alpha=1.
  glClearColor(0.f,0.f,0.f,0.f);glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);glClearColor(oldClear[0],oldClear[1],oldClear[2],oldClear[3]);
 {
 ScopedShaderBinding binding(shader_.GetGLID());GLuint program=shader_.GetGLID();
 auto uf=[&](const char* n,float val){GLint loc=glGetUniformLocation(program,n);if(loc>=0)glUniform1f(loc,val);};
 auto uv=[&](const char* n,V3 p){GLint loc=glGetUniformLocation(program,n);if(loc>=0)glUniform3f(loc,p.x,p.y,p.z);};
 glUniformMatrix4fv(glGetUniformLocation(program,"uMVP"),1,GL_FALSE,mvp.m);
 glUniformMatrix4fv(glGetUniformLocation(program,"uModel"),1,GL_FALSE,model.m);
 uf("uTime",t);uf("uExplode",values_[EXPLODE]);uf("uExplodeNoise",values_[EXPLODE_NOISE]);
 // v2.0 deliberately removes the glitch/displace sliders: disable their shader uniforms.
 uf("uDisplace",0.f);uf("uGlitchStretchAngle",0.f);uf("uGlitchAxisAngle",0.f);
 uv("uLight",light);uv("uLightSecondary",secondaryLight);uv("uCamera",cam);
 uf("uAmbient",values_[AMBIENT]);
 uf("uPower",l>0?values_[INTENSITY]*6.f:0.f);
 uf("uSecondaryEnabled",l>0&&values_[SECONDARY_ON]>=0.5f?1.f:0.f);
 uv("uLightColor",hueSaturation(values_[LIGHT_HUE],values_[LIGHT_SAT]));
 uv("uSecondaryColor",hueSaturation(values_[SECONDARY_HUE],values_[SECONDARY_SAT]));
 // Render Mode: 0=full textured triangles, 1=triangle wireframe,
 // 2=point cloud. Preserve GL state for other Resolume clips.
 GLint polygonModes[2]={GL_FILL,GL_FILL};glGetIntegerv(GL_POLYGON_MODE,polygonModes);
 GLfloat previousPointSize=1.f;glGetFloatv(GL_POINT_SIZE,&previousPointSize);
 GLfloat previousLineWidth=1.f;glGetFloatv(GL_LINE_WIDTH,&previousLineWidth);
 GLboolean programPointSizeWasEnabled=glIsEnabled(GL_PROGRAM_POINT_SIZE);
 glDisable(GL_PROGRAM_POINT_SIZE); // use the Point Size slider, not shader defaults
 const int mode=std::clamp(int(std::lround(values_[RENDER_MODE]*2.f)),0,2);
 glPolygonMode(GL_FRONT_AND_BACK,mode==1?GL_LINE:GL_FILL);
 glPointSize(1.f+values_[POINT_SIZE]*11.f);
 if(mode==1)glLineWidth(1.f);
 glActiveTexture(GL_TEXTURE0);glUniform1i(glGetUniformLocation(program,"uTexture"),0);
 for(const auto& part:parts_){
  if(kHideBackgroundMeshes && part.backgroundMesh)continue;
  glUniform1i(glGetUniformLocation(program,"uHasTexture"),part.texture?1:0);
  glBindTexture(GL_TEXTURE_2D,part.texture);glBindVertexArray(part.vao);
  glDrawElements(mode==2?GL_POINTS:GL_TRIANGLES,part.count,GL_UNSIGNED_INT,nullptr);
 }
 glPolygonMode(GL_FRONT,polygonModes[0]);glPolygonMode(GL_BACK,polygonModes[1]);
 glPointSize(previousPointSize);glLineWidth(previousLineWidth);
 if(programPointSizeWasEnabled)glEnable(GL_PROGRAM_POINT_SIZE);
 }
 glBindVertexArray(prevVAO);glBindTexture(GL_TEXTURE_2D,prevTex);glUseProgram(prevProgram);
 glColorMask(oldMask[0],oldMask[1],oldMask[2],oldMask[3]);
  if(!depth)glDisable(GL_DEPTH_TEST);if(blend)glEnable(GL_BLEND);if(scissor)glEnable(GL_SCISSOR_TEST);
 return FF_SUCCESS;
}
FFResult FFGLGradients::DeInitGL(){releaseModel();shader_.FreeGLResources();return FF_SUCCESS;}
