#pragma once
#include <FFGLSDK.h>
#include <array>
#include <string>
#include <vector>
#include <filesystem>
#include <chrono>
#include <memory>
#include <assimp/Importer.hpp>
#include <assimp/scene.h>

class FFGLGradients final : public CFFGLPlugin {
public:
 FFGLGradients();
 FFResult InitGL(const FFGLViewportStruct* vp) override;
 FFResult ProcessOpenGL(ProcessOpenGLStruct* pGL) override;
 FFResult DeInitGL() override;
 FFResult SetFloatParameter(unsigned int index,float value) override;
 float GetFloatParameter(unsigned int index) override;
 FFResult SetTextParameter(unsigned int index,const char* value) override;
 char* GetTextParameter(unsigned int index) override;
private:
 struct Vertex {float p[3], n[3], uv[2], seed, faceDirection[3], faceSeed, corner;};
 struct Part {GLuint vao=0,vbo=0,ebo=0,texture=0; GLsizei count=0; bool backgroundMesh=false; unsigned meshIndex=0; const aiNode* node=nullptr; std::vector<Vertex> vertices; std::vector<unsigned> triangles; std::vector<Vertex> drawVertices;};
 std::vector<Part> parts_;
 std::unique_ptr<Assimp::Importer> importer_;
 const aiScene* scene_=nullptr;
 float normalizedScale_=1.f;
 void updateAnimation(float seconds);
 ffglex::FFGLShader shader_;
 std::array<float,20> values_{};
 unsigned width_=1920,height_=1080;
 std::string folder_, status_;
 std::vector<std::filesystem::path> files_;
 std::filesystem::path loaded_;
 int selected_=-1;
 bool reload_=true;
 std::chrono::steady_clock::time_point started_, lastFrame_;
 double animationSeconds_=0.0;
 bool scanAndLoad();
 bool loadModel(const std::filesystem::path& path);
 void releaseModel();
 void createFallback();
 GLuint loadTexture(const std::filesystem::path& p);
};
