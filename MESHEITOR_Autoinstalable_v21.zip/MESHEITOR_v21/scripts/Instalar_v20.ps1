$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$reports = Join-Path $root 'INFORMES'
New-Item -Path $reports -ItemType Directory -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$report = Join-Path $reports "resultado_$stamp.txt"
$log = Join-Path $reports "compilacion_$stamp.log"
function Report([string]$message) {
  Write-Host $message
  Add-Content -LiteralPath $report -Value $message -Encoding UTF8
}
try {
  Report 'MESHEITOR v2.1 - 20 parametros, 50 modelos, doble iluminacion y explode noise'
  $running = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^Arena$|^Resolume Arena$|^Arena 7$' }
  if ($running) { throw 'Cierra Resolume Arena completamente antes de iniciar la actualizacion.' }
  $base = Join-Path $env:LOCALAPPDATA 'Arena3DFFGLBuild\ffgl'
  $source = Join-Path $base 'source\plugins\Arena3DMesh'
  $project = Join-Path $base 'build\windows\Arena3DMesh.vcxproj'
  $dll = Join-Path $base 'binaries\x64\Release\MESHEITOR.dll'
  if (!(Test-Path $project)) { throw "Falta el proyecto: $project" }
  if (!(Test-Path $source)) { throw "Falta el directorio: $source" }
  $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
  if (!(Test-Path $vswhere)) { throw 'No existe vswhere.exe. Falta Visual Studio Build Tools.' }
  $vs = (& $vswhere -latest -products '*' -requires Microsoft.Component.MSBuild -property installationPath | Select-Object -First 1)
  if (!$vs) { throw 'No se encontro Visual Studio con MSBuild.' }
  $msbuild = Join-Path $vs 'MSBuild\Current\Bin\MSBuild.exe'
  if (!(Test-Path $msbuild)) { throw "No se encontro MSBuild: $msbuild" }
  $sdkRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\Include'
  $sdk = Get-ChildItem $sdkRoot -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^10\.0\.\d+\.0$' } | Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1
  if (!$sdk) { throw 'No se encontro Windows SDK valido.' }
  Report "SDK seleccionado: $($sdk.Name)"
  Report "MSBuild: $msbuild"
  $backup = Join-Path $reports "backup_$stamp"
  New-Item $backup -ItemType Directory -Force | Out-Null
  foreach ($name in @('FFGLGradients.cpp','FFGLGradients.h')) {
    $existing = Join-Path $source $name
    if (Test-Path $existing) { Copy-Item -LiteralPath $existing -Destination (Join-Path $backup $name) -Force }
  }
  Copy-Item -LiteralPath $project -Destination (Join-Path $backup 'Arena3DMesh.vcxproj') -Force
  Report "Backup: $backup"
  foreach ($name in @('FFGLGradients.cpp','FFGLGradients.h')) {
    Copy-Item -LiteralPath (Join-Path (Join-Path $root 'src') $name) -Destination (Join-Path $source $name) -Force
  }
  # Edit only the installed plugin project, preserve all other SDK files.
  [xml]$xml = Get-Content -LiteralPath $project -Raw
  $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
  $ns.AddNamespace('m','http://schemas.microsoft.com/developer/msbuild/2003')
  $platformNode = $xml.SelectSingleNode('//m:WindowsTargetPlatformVersion',$ns)
  if (!$platformNode) { throw 'WindowsTargetPlatformVersion no existe en el proyecto.' }
  $platformNode.InnerText = $sdk.Name
  $release = $xml.SelectSingleNode("//m:ItemDefinitionGroup[contains(@Condition, 'Release|x64')]/m:ClCompile",$ns)
  if (!$release) { throw 'ClCompile Release|x64 no encontrado.' }
  $runtime = $release.SelectSingleNode('m:RuntimeLibrary',$ns)
  if (!$runtime) { throw 'RuntimeLibrary Release|x64 no encontrado.' }
  $runtime.InnerText = 'MultiThreaded'
  $pre = $release.SelectSingleNode('m:PreprocessorDefinitions',$ns)
  if ($pre -and !$pre.InnerText.Contains('NOMINMAX')) { $pre.InnerText = "NOMINMAX;" + $pre.InnerText }
  # Renombrar el artefacto nativo, conservando el proyecto de desarrollo existente.
  $targetNameNodes = $xml.SelectNodes('//m:TargetName',$ns)
  if ($targetNameNodes.Count -eq 0) { throw 'No existe TargetName en el proyecto; no es seguro renombrar la DLL.' }
  foreach ($node in $targetNameNodes) { $node.InnerText = 'MESHEITOR' }
  $xml.Save($project)
  $previousHash = if (Test-Path $dll) { (Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash } else { $null }
  # Ensure resulting DLL is produced by this run rather than a stale binary.
  $buildStart = Get-Date
  Report 'Rebuild completo Release x64 en curso. No cierres esta ventana.'
  & $msbuild $project '/t:Rebuild' '/p:Configuration=Release' '/p:Platform=x64' '/m:2' '/nologo' '/verbosity:minimal' '/p:VcpkgEnableManifest=false' '/p:TargetName=MESHEITOR' 2>&1 | Out-File -LiteralPath $log -Encoding UTF8
  $code = $LASTEXITCODE
  Report "MSBuild exit code: $code"
  Report "Log: $log"
  if ($code -ne 0) {
    $errors = Select-String -LiteralPath $log -Pattern 'error C\d+|error LNK\d+|error MSB\d+|fatal error' | Select-Object -First 12
    foreach ($e in $errors) { Report $e.Line }
    throw 'No se genero una DLL nueva. La instalada permanece intacta.'
  }
  if (!(Test-Path $dll)) { throw "MSBuild reporto exito pero no existe DLL: $dll" }
  $artifact = Get-Item -LiteralPath $dll
  if ($artifact.LastWriteTime -lt $buildStart.AddSeconds(-3)) { throw 'La DLL tiene una fecha anterior al Rebuild. No se instalara.' }
  Report "DLL generada: $dll"
  Report "Tamano: $($artifact.Length) bytes"
  Report "SHA256: $((Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash)"
  $answer = Read-Host 'Copiar la DLL nueva a Resolume Arena? [S/N]'
  if ($answer -notmatch '^[Ss]') { Report 'Compilacion exitosa. Instalacion omitida por el usuario.'; exit 0 }
  $running = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^Arena$|^Resolume Arena$|^Arena 7$' }
  if ($running) { throw 'Resolume Arena esta abierto. Cerralo completamente y ejecuta de nuevo el instalador.' }
  $docs = [Environment]::GetFolderPath('MyDocuments')
  $destinations = @((Join-Path $docs 'Resolume Arena\Extra Effects'), (Join-Path $docs 'Resolume\Extra Effects'))
  foreach ($dest in $destinations) {
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $target = Join-Path $dest 'MESHEITOR.dll'
    if (Test-Path $target) {
      Copy-Item -LiteralPath $target -Destination (Join-Path $backup ("$(Split-Path (Split-Path $dest -Parent) -Leaf)_MESHEITOR.dll")) -Force
    }
    Copy-Item -LiteralPath $dll -Destination $target -Force
    if ((Get-FileHash -LiteralPath $target).Hash -ne (Get-FileHash -LiteralPath $dll).Hash) { throw "Fallo la verificacion: $target" }
    Report "Instalada y verificada: $target"
    # Retirar el plugin viejo del directorio activo para evitar duplicados; conservar respaldo.
    $old = Join-Path $dest 'Arena3DMesh.dll'
    if (Test-Path $old) {
      $oldBackup = Join-Path $backup ("$(Split-Path (Split-Path $dest -Parent) -Leaf)_Arena3DMesh_anterior.dll")
      Copy-Item -LiteralPath $old -Destination $oldBackup -Force
      Remove-Item -LiteralPath $old -Force
      Report "Plugin anterior respaldado y retirado de: $old"
    }
  }
  Report 'MESHEITOR instalado. Reinicia Arena y crea un clip nuevo, no reutilices el antiguo.'
  exit 0
} catch {
  Report "ERROR: $($_.Exception.Message)"
  Report "Informe: $report"
  exit 1
}
