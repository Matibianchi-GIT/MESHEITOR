@echo off
setlocal
cd /d "%~dp0"
title MESHEITOR v2.1 - Resolume Arena 7
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Instalar_v20.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo ERROR: Revisar carpeta INFORMES.
pause
exit /b %RESULT%
