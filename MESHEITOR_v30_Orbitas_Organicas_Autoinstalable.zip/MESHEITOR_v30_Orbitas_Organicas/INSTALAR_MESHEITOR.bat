﻿@echo off
setlocal
cd /d "%~dp0"
title MESHEITOR v3.0 - FBX Texture ON/OFF + Reflection sin Spout
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Instalar_MESHEITOR.ps1"
set "STATUS=%ERRORLEVEL%"
echo.
if not "%STATUS%"=="0" echo Se produjo un error. Revisar la carpeta INFORMES.
if "%STATUS%"=="0" echo Instalador finalizado. Reinicia Resolume Arena.
pause
exit /b %STATUS%
