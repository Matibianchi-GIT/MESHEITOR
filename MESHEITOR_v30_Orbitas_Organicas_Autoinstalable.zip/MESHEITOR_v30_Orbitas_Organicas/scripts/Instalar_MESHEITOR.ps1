﻿# MESHEITOR v2.2 - instalador independiente para Windows x64 (PowerShell 5.1)
# Instala dependencias solo con permiso, genera un proyecto propio, compila y verifica DLL.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$reports = Join-Path $root 'INFORMES'
New-Item -Path $reports -ItemType Directory -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$report = Join-Path $reports "resultado_$stamp.txt"
$buildLog = Join-Path $reports "compilacion_$stamp.log"
function Note([string]$s) { Write-Host $s; Add-Content -LiteralPath $report -Value $s -Encoding UTF8 }
function Need([bool]$condition,[string]$message) { if (-not $condition) { throw $message } }
function Find-VS {
  $vw = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
  if (!(Test-Path -LiteralPath $vw)) { return $null }
  $found = & $vw -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.Component.MSBuild -property installationPath 2>$null | Select-Object -First 1
  if (!$found) { return $null }
  $ms = Join-Path $found 'MSBuild\Current\Bin\MSBuild.exe'
  if (!(Test-Path -LiteralPath $ms)) { return $null }
  return $ms
}
function Install-Winget([string]$id,[string]$label,[string]$override='') {
  Note "Instalando $label (winget)..."
  $args = @('install','--id',$id,'--exact','--source','winget','--accept-package-agreements','--accept-source-agreements')
  if ($override) { $args += @('--override',$override) }
  & winget @args
  if ($LASTEXITCODE -ne 0) { throw "Falló la instalación de $label (código $LASTEXITCODE)." }
}
try {
  Note '=== MESHEITOR v3.0 ORBITAS ORGANICAS (SIN SPOUT) - Instalacion Windows x64 ==='
  Need ([Environment]::Is64BitOperatingSystem) 'Se requiere Windows x64.'
  Need (Test-Path -LiteralPath (Join-Path $root 'src\FFGLGradients.cpp')) 'No se encontraron los fuentes. Extrae el ZIP completo.'
  $arenaRunning = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -match '^(Arena|Resolume Arena|Arena 7)$'})
  Need ($arenaRunning.Count -eq 0) 'Cierra Resolume Arena antes de instalar.'
  Note "Carpeta del paquete: $root"
  Note "Sistema operativo: $([Environment]::OSVersion.VersionString)"
  $missing = @()
  if (!(Get-Command git -ErrorAction SilentlyContinue)) { $missing += 'Git' }
  if (!(Get-Command cmake -ErrorAction SilentlyContinue)) { $missing += 'CMake' }
  if (!(Find-VS)) { $missing += 'Visual Studio 2022 Build Tools + C++' }
  if ($missing.Count -gt 0) {
    Note "Dependencias ausentes: $($missing -join ', ')"
    Need ([bool](Get-Command winget -ErrorAction SilentlyContinue)) 'Falta winget. Instala App Installer desde Microsoft Store y reintenta.'
    Note 'Visual Studio C++ puede ocupar varios GB y requerir aprobación del administrador.'
    $yes = Read-Host '¿Instalar herramientas ausentes mediante winget? [S/N]'
    Need ($yes -match '^[Ss]') 'Instalación cancelada; no se modificó Windows.'
    if ($missing -contains 'Git') { Install-Winget 'Git.Git' 'Git' }
    if ($missing -contains 'CMake') { Install-Winget 'Kitware.CMake' 'CMake' }
    if ($missing -contains 'Visual Studio 2022 Build Tools + C++') {
      Install-Winget 'Microsoft.VisualStudio.2022.BuildTools' 'Visual Studio C++' '--wait --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended'
    }
    $env:PATH = ([Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User') + ';' + $env:PATH + ';C:\Program Files\Git\cmd;C:\Program Files\CMake\bin')
  }
  Need ([bool](Get-Command git -ErrorAction SilentlyContinue)) 'Git no disponible. Reabre la consola y reintenta.'
  Need ([bool](Get-Command cmake -ErrorAction SilentlyContinue)) 'CMake no disponible. Reabre la consola y reintenta.'
  $msbuild = Find-VS
  Need ([bool]$msbuild) 'No se detectó MSVC + MSBuild. Revisa Visual Studio Installer y reinicia Windows si es necesario.'
  $sdkRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\Include'
  $sdk = Get-ChildItem -LiteralPath $sdkRoot -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^10\.0\.\d+\.0$' -and (Test-Path (Join-Path $_.FullName 'um\Windows.h')) } | Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1
  Need ([bool]$sdk) 'Windows 10/11 SDK no instalado. Agrega Windows SDK en Visual Studio Installer.'
  Note "Windows SDK: $($sdk.Name)"
  Note "MSBuild: $msbuild"
  $work = Join-Path $env:LOCALAPPDATA 'MESHEITORBuild'
  New-Item -ItemType Directory -Force -Path $work | Out-Null
  $vcpkg = Join-Path $work 'vcpkg'
  if (!(Test-Path -LiteralPath (Join-Path $vcpkg 'vcpkg.exe'))) {
    if (!(Test-Path -LiteralPath $vcpkg)) {
      Note 'Descargando vcpkg desde Microsoft...'
      & git clone --depth 1 https://github.com/microsoft/vcpkg.git $vcpkg
      Need ($LASTEXITCODE -eq 0) 'Git no pudo descargar vcpkg.'
    }
    Note 'Preparando vcpkg...'
    & (Join-Path $vcpkg 'bootstrap-vcpkg.bat') -disableMetrics
    Need ($LASTEXITCODE -eq 0) 'No se pudo preparar vcpkg.'
  }
  Note 'Preparando Assimp (x64-windows-static, runtime /MT)...'
  & (Join-Path $vcpkg 'vcpkg.exe') install 'assimp:x64-windows-static' --classic
  Need ($LASTEXITCODE -eq 0) 'Assimp no se pudo instalar con vcpkg.'
  $ffgl = Join-Path $work 'ffgl'
  if (!(Test-Path -LiteralPath (Join-Path $ffgl 'build\windows\Gradient.vcxproj'))) {
    Need (!(Test-Path -LiteralPath $ffgl)) "Existe un FFGL incompleto: $ffgl. No se eliminará automáticamente. Renómbralo y reintenta."
    Note 'Descargando FFGL SDK oficial de Resolume...'
    & git clone --depth 1 https://github.com/resolume/ffgl.git $ffgl
    Need ($LASTEXITCODE -eq 0) 'No se pudo descargar el SDK FFGL.'
  }
  $projectDir = Join-Path $ffgl 'build\windows'
  $template = Join-Path $projectDir 'Gradient.vcxproj'
  $project = Join-Path $projectDir 'MESHEITOR.vcxproj'
  $srcDir = Join-Path $ffgl 'source\plugins\MESHEITOR'
  New-Item -ItemType Directory -Force -Path $srcDir | Out-Null
  foreach ($name in @('FFGLGradients.cpp','FFGLGradients.h')) {
    Copy-Item -LiteralPath (Join-Path (Join-Path $root 'src') $name) -Destination (Join-Path $srcDir $name) -Force
  }
  # El proyecto se deriva del ejemplo Source (Gradients), pero no modifica el ejemplo original.
  [xml]$xml = Get-Content -LiteralPath $template -Raw
  $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
  $ns.AddNamespace('m','http://schemas.microsoft.com/developer/msbuild/2003')
  $oldProject = 'source\plugins\Gradients\'
  $text = $xml.OuterXml.Replace($oldProject, 'source\plugins\MESHEITOR\')
  # En proyectos MSBuild puede haber GUID o nombres Gradient en la configuración; se cambia el nombre de salida independientemente.
  $text = $text.Replace('10.0.18362.0', $sdk.Name)
  [xml]$xml = $text
  $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
  $ns.AddNamespace('m','http://schemas.microsoft.com/developer/msbuild/2003')
  foreach ($s in $xml.SelectNodes('//m:WindowsTargetPlatformVersion',$ns)) { $s.InnerText = $sdk.Name }
  foreach ($s in $xml.SelectNodes('//m:PlatformToolset',$ns)) { $s.InnerText = 'v143' }
  $group = $xml.SelectSingleNode("//m:ItemDefinitionGroup[contains(@Condition, 'Release|x64')]/m:ClCompile",$ns)
  Need ([bool]$group) 'El SDK FFGL cambió su proyecto Gradients: falta configuración Release|x64.'
  $runtime = $group.SelectSingleNode('m:RuntimeLibrary',$ns)
  if (!$runtime) { $runtime = $xml.CreateElement('RuntimeLibrary',$xml.DocumentElement.NamespaceURI); [void]$group.AppendChild($runtime) }
  $runtime.InnerText = 'MultiThreaded'
  $pre = $group.SelectSingleNode('m:PreprocessorDefinitions',$ns)
  if (!$pre) { $pre = $xml.CreateElement('PreprocessorDefinitions',$xml.DocumentElement.NamespaceURI); [void]$group.AppendChild($pre) }
  if ($pre.InnerText -notmatch '(^|;)NOMINMAX(;|$)') { $pre.InnerText = 'NOMINMAX;' + $pre.InnerText }
  $lang = $group.SelectSingleNode('m:LanguageStandard',$ns)
  if (!$lang) { $lang = $xml.CreateElement('LanguageStandard',$xml.DocumentElement.NamespaceURI); [void]$group.AppendChild($lang) }
  $lang.InnerText = 'stdcpp17'
  $include = $group.SelectSingleNode('m:AdditionalIncludeDirectories',$ns)
  if (!$include) { $include = $xml.CreateElement('AdditionalIncludeDirectories',$xml.DocumentElement.NamespaceURI); [void]$group.AppendChild($include) }

  $link = $xml.SelectSingleNode("//m:ItemDefinitionGroup[contains(@Condition, 'Release|x64')]/m:Link",$ns)
  Need ([bool]$link) 'Falta sección Link para Release|x64.'
  $deps = $link.SelectSingleNode('m:AdditionalDependencies',$ns)
  if (!$deps) { $deps = $xml.CreateElement('AdditionalDependencies',$xml.DocumentElement.NamespaceURI); [void]$link.AppendChild($deps) }
  $deps.InnerText = 'windowscodecs.lib;ole32.lib;' + $deps.InnerText
  $prop = $xml.CreateElement('PropertyGroup',$xml.DocumentElement.NamespaceURI)
  foreach ($item in @(@('TargetName','MESHEITOR'),@('VcpkgEnabled','true'),@('VcpkgTriplet','x64-windows-static'),@('VcpkgRoot',($vcpkg+'\')),@('VcpkgEnableManifest','false'))) {
    $n = $xml.CreateElement($item[0],$xml.DocumentElement.NamespaceURI);$n.InnerText=$item[1];[void]$prop.AppendChild($n)
  }
  [void]$xml.DocumentElement.AppendChild($prop)
  $targets = Join-Path $vcpkg 'scripts\buildsystems\msbuild\vcpkg.targets'
  Need (Test-Path -LiteralPath $targets) 'vcpkg.targets no existe.'
  $imp = $xml.CreateElement('Import',$xml.DocumentElement.NamespaceURI)
  $imp.SetAttribute('Project',$targets)
  [void]$xml.DocumentElement.AppendChild($imp)
  $xml.Save($project)
  Note "Proyecto generado: $project"
  $env:VCPKG_ROOT=$vcpkg
  $buildStart = Get-Date
  Note 'Compilando MESHEITOR en Release x64 (log en INFORMES)...'
  & $msbuild $project '/t:Rebuild' '/p:Configuration=Release' '/p:Platform=x64' '/p:TargetName=MESHEITOR' "/p:WindowsTargetPlatformVersion=$($sdk.Name)" '/p:VcpkgEnableManifest=false' '/m:2' '/nologo' '/verbosity:minimal' 2>&1 | Out-File -LiteralPath $buildLog -Encoding UTF8
  $buildExit = $LASTEXITCODE
  Note "MSBuild código: $buildExit"
  Note "Log: $buildLog"
  if ($buildExit -ne 0) {
    Select-String -LiteralPath $buildLog -Pattern 'error C\d+|error LNK\d+|error MSB\d+|fatal error' | Select-Object -First 12 | ForEach-Object { Note $_.Line }
    throw 'Compilación fallida. No se instaló ninguna DLL.'
  }
  $dll = Join-Path $ffgl 'binaries\x64\Release\MESHEITOR.dll'
  Need (Test-Path -LiteralPath $dll) "Compilación finalizada pero falta la DLL MESHEITOR: $dll"
  $bin = Get-Item -LiteralPath $dll
  Need ($bin.LastWriteTime -gt $buildStart.AddSeconds(-5)) 'DLL anterior al proceso de compilación: no se instalará.'
  Need ($bin.Length -gt 100000) 'La DLL generada tiene un tamaño anormal.'
  Note "DLL compilada: $dll ($($bin.Length) bytes)"
  Note "SHA256: $((Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash)"
  $answer = Read-Host '¿Instalar esta DLL en Resolume? [S/N]'
  if ($answer -notmatch '^[Ss]') { Note 'Compilación correcta; no se instaló por decisión del usuario.';exit 0 }
  Need (@(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -match '^(Arena|Resolume Arena|Arena 7)$'}).Count -eq 0) 'Cierra Arena antes de copiar la DLL.'
  $docs = [Environment]::GetFolderPath('MyDocuments')
  $backupDir = Join-Path $reports "respaldo_dll_$stamp"
  New-Item -Path $backupDir -ItemType Directory -Force | Out-Null
  foreach ($rel in @('Resolume\Extra Effects','Resolume Arena\Extra Effects')) {
    $dest = Join-Path $docs $rel
    New-Item -Path $dest -ItemType Directory -Force | Out-Null
    $target = Join-Path $dest 'MESHEITOR.dll'
    if (Test-Path -LiteralPath $target) {
      $label = ($rel -replace '[\\ /]','_')
      Copy-Item -LiteralPath $target -Destination (Join-Path $backupDir ($label+'.dll')) -Force
    }
    Copy-Item -LiteralPath $dll -Destination $target -Force
    Need ((Get-FileHash -LiteralPath $target).Hash -eq (Get-FileHash -LiteralPath $dll).Hash) "Error verificando la copia: $target"
    Note "Instalado: $target"
  }
  Note 'Sin Spout: esta version no descarga ni instala bibliotecas Spout.'
  Note 'No se eliminan bibliotecas Spout de versiones anteriores: otras aplicaciones pueden utilizarlas.'
  Note 'Instalación completada. Reinicia Resolume Arena 7 y busca MESHEITOR en Sources.'
  exit 0
} catch {
  Note "ERROR: $($_.Exception.Message)"
  Note "Informe: $report"
  exit 1
}
